package org.anudip.autowireApp.config;
//It is act as setter based Dependency Injection

import org.anudip.autowireApp.bean.Address;
import org.anudip.autowireApp.bean.Worker;
import org.springframework.context.annotation.Bean;
public class WorkerConfig {

	@Bean(name="current")
	public Address address1() {
		Address add=new Address();
		add.setStreet("23 Bandra West");
		add.setCity("Mumbai");
		add.setPin(400034);
		return add;
	}
	@Bean(name="parmanent")
	public Address address2() {
		Address add=new Address();
		add.setStreet("53 Rathtala Road");
		add.setCity("Kolkata");
		add.setPin(700053);
		return add;
	}
	
	@Bean
	public Worker worker() {
		Worker wk=new Worker();
		wk.setEmployeeId(10100);
		wk.setEmployeeName("Liz harbert");
		wk.setEmployeeSalary(45000.00);
		return wk;
		
		
	}
	
	
	
}
