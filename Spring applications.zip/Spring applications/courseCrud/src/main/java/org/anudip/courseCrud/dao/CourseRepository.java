package org.anudip.courseCrud.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

import org.anudip.courseCrud.bean.Course;
public interface CourseRepository extends JpaRepository<Course,Long> {

	@Query("select Count(courseId) from Course")
	public int getCourseCount();
	
	@Query("select courseId from Course")
	public List<Long> getAllCourseIds();
}


