package org.anudip.calculatorApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
