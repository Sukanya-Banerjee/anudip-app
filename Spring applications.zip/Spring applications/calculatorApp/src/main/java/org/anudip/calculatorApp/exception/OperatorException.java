package org.anudip.calculatorApp.exception;

public class OperatorException extends RuntimeException{
	
}
