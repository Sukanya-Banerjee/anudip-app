package org.anudip.inheritance;

public class InheritanceMain4 {

	public static void main(String[] args) {
		 // Creating an object of the Student class
        Student student = new Student("Sukanya", 22, "E");

        // Calling the "speak" method of the Student class (inherited from the parent class)
        student.speak();

        // Calling the "study" method of the Student class
        student.study();
    }
	
}


