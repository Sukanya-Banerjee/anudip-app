package org.anudip.inheritance;

public class Car extends Vehical {
String color;
	
	public Car(String brand, String model, int year, String color) {
		super(brand, model, year);
        this.color = color;
    }
	public void honk() {
        System.out.println(year + " " + brand + " " + model + " in " + color + " honks: Honk!");
    }

}
