package org.anudip.app;
import java.util.Scanner;
public class FactorialApp {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a Number: ");
	int num=sc.nextInt();
	int i=1,factorial=1;
	while(i<=num)
	{
		factorial=factorial*i;
		i++;
	}
    System.out.println("Factorial of the number is: "+factorial);
	}

}
