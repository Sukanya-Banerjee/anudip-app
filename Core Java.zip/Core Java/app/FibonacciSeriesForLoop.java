package org.anudip.app;
import java.util.Scanner;
public class FibonacciSeriesForLoop {

	public static void main(String[] args) {
		int n,p=0,q=0,r=1;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value of n: ");
		n=s.nextInt();
		System.out.println("Fibonacci Series: ");
		for(int i=1;i<=n;i++)
		{
			p=q;
			q=r;
			r=p+q;
			System.out.println(" "+p);
		}

	}

}
