package org.anudip.app;

public class LoopDemo {

	public static void main(String[] args) {
	int counter=0;
	while(counter<5) {
		System.out.println("Hello");
		counter++;
	}//end of looping statement
	System.out.println("outside the loop");

	}

}
