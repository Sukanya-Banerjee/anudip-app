package org.anudip.app;

public class LoopDemo2 {

	public static void main(String[] args) {
	int counter=10;
	do {
		System.out.println("Hello");
		counter++;
	}
	while(counter<5);// end looping statement
System.out.println("outside the loop");
	}

}
