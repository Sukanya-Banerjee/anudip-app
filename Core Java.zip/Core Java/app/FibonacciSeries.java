package org.anudip.app;
import java.util.Scanner;
public class FibonacciSeries {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a number of series: ");
	int num=scanner.nextInt();
	//System.out.println("Terms of fibonacci series: "+n);
	int fib1=0;
	int fib2=1;
	int fib3;
	int i=1;
	while(i<=num)
	{
		System.out.println(" "+fib1);
		fib3=fib1+fib2;
		fib1=fib2;
		fib2=fib3;
		i++;
	}
	

	}

}
