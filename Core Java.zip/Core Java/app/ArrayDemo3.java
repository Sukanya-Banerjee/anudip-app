package org.anudip.app;
//import java.util.Arrays;
import java.util.Scanner;
public class ArrayDemo3 {

	public static void main(String[] args) {
    int[]arr= {60,80,20,100,70,10,40,90,50,30};
    Scanner scanner=new Scanner(System.in);
    System.out.println("Enter a number to find whether is present in array & location: ");
    int n=scanner.nextInt();
    boolean flag=false;
    for(int i=0;i<arr.length;i++)
    {
    	if(arr[i]==n)
    	{
    		System.out.println("The value present in the location: "+(i+1));
    		flag=true;
    		break;
    	}//end of if 
    }//end of loop
    if(!flag)
    {
    	System.out.println("Data is not found in array");
    }

	}

}
