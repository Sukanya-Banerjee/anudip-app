package org.anudip.app;
import java.util.Scanner;
public class ArrayEven {

			public static void main(String[] args) {
				Scanner scanner = new Scanner(System.in);

		        // Accept the size of the int array
		        System.out.print("Enter the size of the array: ");
		        int size = scanner.nextInt();

		        int[] numbers = new int[size];

		        // Accept and store the data into the array
		        for (int i = 0; i < size; i++) {
		            System.out.print("Enter number " + (i + 1) + ": ");
		            numbers[i] = scanner.nextInt();
		        }

		        // Display even numbers using for-each loop
		        System.out.print("Even numbers in the array: ");
		        boolean EvenNumber = false;
		        for (int number : numbers) {
		            if (number % 2 == 0) {
		                System.out.print(number + " ");
		                EvenNumber = true;
		            }
		        }

		        if (!EvenNumber) {
		            System.out.println("No even numbers found");
		        } else {
		            System.out.println();

	}
			}

}
