package org.anudip.application;
import org.anudip.service.StudentService;
import java.util.Scanner;
import org.anudip.bean.Student;

public class StudentArrayMain {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		//Accept student details
		//array declaration
		Student [] studArr=new Student[3];
		//within loop 3 students details are accepted & stored in array
		for(int index=0;index<studArr.length;index++) {
		System.out.println("Enter Student Roll: ");
		int roll=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter student name: ");
		String name=scanner.nextLine();
		System.out.println("Enter student course: ");
		String course=scanner.nextLine();
		System.out.println("Enter student marks: ");
		double marks=Double.parseDouble(scanner.nextLine());
				Student student=new Student(roll,name,course,marks);
				String grade=StudentService.calculateGrade(student);
				student.setStudentGrade(grade);
				studArr[index]=student;
  
	}//end of for loop
		String headings= String.format("%-5s %-15s %-10s %-5s %-5s","Roll","Name","Course","Marks","Grade");
		System.out.println(headings);
		//display all students records from array
		for(Student std:studArr)
		{
			System.out.println(std);
		}

}
}