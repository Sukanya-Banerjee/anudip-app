package org.anudip.mavenApplication.single;

public class MultiDemo {
       private int i;
       
      public MultiDemo() {
    	   i=10;
       }
	public void putdata(int x) {
		i=x;
	}

	public int getdata() {
		return i;
	}
	
	
}
