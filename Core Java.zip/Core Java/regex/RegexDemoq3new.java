package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Pattern;
public class RegexDemoq3new {

	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter the date of joining (dd-mm-yyyy): ");
		        String date = scanner.nextLine();
		        String regexPattern = "^(0[1-9]|1\\d|2\\d|3[01])-(0[1-9]|1[0-2])-\\d{4}";
		        boolean isValidDate = Pattern.matches(regexPattern, date);

		        if (isValidDate) {
		            System.out.println("Date is valid.");
		        } else {
		            System.out.println("Date is not valid or does not match the format.");
		        }
		    }
		

	}
