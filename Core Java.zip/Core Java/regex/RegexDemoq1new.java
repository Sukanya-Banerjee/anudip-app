package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexDemoq1new {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a name of a person: ");
	String name=sc.nextLine();
	Pattern p1=Pattern.compile("(Mr|Mrs|Ms)\\.[A-Za-z' ']+$");
	Matcher m1=p1.matcher(name);
	System.out.println(m1.matches());
	if(m1.matches())
	{
		System.out.println("This name is valid");
	}
	else
	{
		System.out.println("This name can not be considered as valid");
	}
	}
}
