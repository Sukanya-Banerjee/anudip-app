package org.anudip.regex;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class RegexDemoq3 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your date of joinning in DD-MM-YYYY pattern: ");
	String s1=sc.nextLine();
	Pattern p1=Pattern.compile("([0-2][0-9]||3[0-1])+-+(0[0-9]||1[0-2])+-+([0-9][0-9][0-9][0-9])");
	Matcher m1=p1.matcher(s1);
	if(m1.matches())
	{
		System.out.println("It is verified");
	}
	else
	{
		System.out.println("No match found");
	}
	
	}

}
