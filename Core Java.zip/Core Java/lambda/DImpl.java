package org.anudip.lambda;

import org.anudip.interfaceApp.DemoFace;

public class DImpl implements DemoFace {

	@Override
	public void show() {
		System.out.println("Hello World");

	}
	@Override
	public void display() {
		System.out.println("Hi World");

	}
	public void putdata() {
		System.out.println("Hello hi");
	}

}
