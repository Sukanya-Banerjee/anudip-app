package org.anudip.lambda;

public class MyMain {

	public static void main(String[] args) {
		DImpl dd=new DImpl();
		dd.display();
		dd.show();
		dd.putdata();

	}

}
