package org.anudip.lambda;

public interface AdditionFace {
       int add(int x,int y);
}
