package org.anudip.lambda;

import java.util.Scanner;

public class DemoMain {

	public static void main(String[] args) {
		DemoFace df=(str)->{
			String stg="Hello" +str+ "Good Morning";
	        return stg;
		};
		//DemoFace df=new DemoFaceImpl();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a name: ");
		String stk=scanner.nextLine();
		System.out.println(df.showMessage(stk));

	}

}
