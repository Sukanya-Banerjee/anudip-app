package org.anudip.io;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class OddEvenNumberSorter 
{
	    public static void main(String[] args)
	    {
	        Scanner scanner = new Scanner(System.in);

	        int[] numbers = new int[9];
	        int oddCount = 0;
	        int evenCount = 0;
	        for (int i = 0; i < 9; i++)
	        {
	            System.out.print("Enter number " + (i + 1) + ": ");
	            int num = scanner.nextInt();

	            if (num < 0 || num > 9)
	            {
	                System.out.println("Invalid input. Please enter a single-digit number.");
	                i--;
	                continue;
	            }

	            if (num % 2 == 0) 
	            {
	                // Even number
	                numbers[evenCount++] = num;
	            } 
	            else 
	            {
	                // Odd number
	                numbers[oddCount++] = num;
	            }
	        }
	        sortAscending(numbers, oddCount);
	        sortDescending(numbers, evenCount);
	        saveToFile("Odd.txt", numbers, oddCount);
	        saveToFile("Even.txt", numbers, evenCount);
	        System.out.println("Numbers have been sorted and saved to Odd.txt and Even.txt.");
	        scanner.close();
	    }

	    private static void sortAscending(int[] arr, int size) 
	    {
	        for (int i = 0; i < size - 1; i++) {
	            for (int j = 0; j < size - i - 1; j++) {
	                if (arr[j] > arr[j + 1]) {
	                    int temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                }
	            }
	        }
	    }

	    private static void sortDescending(int[] arr, int size) 
	    {
	        for (int i = 0; i < size - 1; i++) {
	            for (int j = 0; j < size - i - 1; j++) {
	                if (arr[j] < arr[j + 1]) {
	                    int temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                }
	            }
	        }
	    }

	    private static void saveToFile(String fileName, int[] arr, int size) 
	    {
	        try
	        {
	            PrintWriter writer = new PrintWriter(new FileWriter(fileName));
	            for (int i = 0; i < size; i++) 
	            {
	                writer.println(arr[i]);
	            }
	            writer.close();
	        } 
	        catch (IOException e) 
	        {
	            System.out.println("Error saving to file: " + e.getMessage());
	        }
	    }
	    
}
