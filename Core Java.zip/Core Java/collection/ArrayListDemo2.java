package org.anudip.mavenApplication.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class ArrayListDemo2 {
	public static void main(String[] args) 
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter numbers of products to store:");
		int no=Integer.parseInt(scanner.nextLine());
	     ArrayList<Product>  productList=new ArrayList<Product>();
	     for(int i=0;i<no;i++) 
	     {
	    	 System.out.println("Enter product details in comma(,) separated String: ");
	    	 String stg=scanner.nextLine();
	    	 String []arr=stg.split(",");
	    	 int id =Integer.parseInt(arr[0]);
	    	 double price=Double.parseDouble(arr[2]);
	    	 Product product=new Product(id,arr[1],price);
			productList.add(product);
	     }//end of loop
	   System.out.println("Display in order of entry:---");
	   productList.forEach(prod->System.out.println(prod));
	   System.out.println("Display ascending order of product Id:---");
	   Collections.sort(productList);
	   productList.forEach(prod->System.out.println(prod));
	   System.out.println("Display decending order of product Id:---");
	   Collections.reverse(productList);
	   productList.forEach(prod->System.out.println(prod));
	   
	     
	}

}
