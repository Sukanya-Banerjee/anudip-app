package org.anudip.mavenApplication.collection;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.Scanner;
public class TreeSetDemo1 {
	public static void main(String[] args) 
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter numbers of products to store:");
		int no=Integer.parseInt(scanner.nextLine());
	     TreeSet<Product>  productSet=new TreeSet<Product>();
	     for(int i=0;i<no;i++) 
	     {
	    	 System.out.println("Enter product details in comma(,) separated String: ");
	    	 String stg=scanner.nextLine();
	    	 String []arr=stg.split(",");
	    	 int id =Integer.parseInt(arr[0]);
	    	 double price=Double.parseDouble(arr[2]);
	    	 Product product=new Product(id,arr[1],price);
			productSet.add(product);
	     }//end of loop
	   System.out.println("Display in order of entry:---");
	   productSet.forEach(prod->System.out.println(prod));
	   System.out.println("Display descending order of product Id:---");
	   Iterator<Product> iterator=productSet.descendingIterator();
	   while(iterator.hasNext()) {
		   Product prod=iterator.next();
		   System.out.println(prod);
	   }
	   
	     
	}

}
