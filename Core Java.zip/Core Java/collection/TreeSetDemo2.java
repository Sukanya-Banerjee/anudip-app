package org.anudip.mavenApplication.collection;
import java.util.TreeSet;
import java.util.Collections;
import java.util.ListIterator;
public class TreeSetDemo2 {
	public static void main(String[] args) {
		TreeSet <String>mySet = new TreeSet<String>();
		mySet.add("Rose");
		mySet.add("Lotus");
		mySet.add("Lily");
		mySet.add("Rose");
		mySet.add("Marigold");
		mySet.add("Jasmine");
		mySet.add("Cosmos");
		mySet.add("Jasmine");
		mySet.add("Delhia");
		mySet.add("Zenia");
		mySet.add("Tulip");
		System.out.println("Display in ascending order:-");
		mySet.forEach(str->System.out.println(str));
		//System.out.println("Display in descending order:-");
	}
}
