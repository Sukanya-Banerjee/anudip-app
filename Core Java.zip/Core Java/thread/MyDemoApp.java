package org.anudip.thread;

public class MyDemoApp {

	public static void main(String[] args) {
		MyDemo md1=new MyDemo("India");
		MyDemo md2=new MyDemo("Bharat");
		md1.setPriority(Thread.MIN_PRIORITY);
		md2.setPriority(Thread.MAX_PRIORITY);
		md1.start();
		md2.start();
		System.out.println("This is main Program");

	}

}
