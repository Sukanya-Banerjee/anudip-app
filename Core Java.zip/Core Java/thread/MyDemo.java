package org.anudip.thread;

public class MyDemo extends Thread {
         private String myName;

		public MyDemo(String myName) {
			super();
			this.myName = myName;
		}
		@Override
		public void run() {
			try {
			for (int i=0;i<5;i++) {
				System.out.println("Hello,I am"+myName);
			Thread.sleep(2000);
			}//end of loop
		}catch(Exception e) {}	
		
}
}