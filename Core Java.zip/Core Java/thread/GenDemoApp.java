package org.anudip.thread;

public class GenDemoApp {

	public static void main(String[] args) {
		GenDemo gd1=new GenDemo("India");
		GenDemo gd2=new GenDemo("Bharat");
		Thread t1=new Thread(gd1);
		Thread t2=new Thread(gd2);
		
		t1.start();
		t2.start();
		System.out.println("This is main Program");

	}

}
