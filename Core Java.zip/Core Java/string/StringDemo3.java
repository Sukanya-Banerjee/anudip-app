package org.anudip.string;

public class StringDemo3 {

	public static void main(String[] args) {
	String str="ABCDEFGH";
	/*char ch1=str.charAt(0);
	 System.out.println(ch1);
	 char ch2=str.charAt(8);
	 System.out.println(ch2);
	 */
	System.out.println("The length of arr: "+str.length());
	for(int i=0; i<str.length();i++)
	{
		char ch=str.charAt(i);
		System.out.println(ch+" ");
	}
    String stg="    XYZPOQ    ";
    System.out.println("The length of stg: "+stg.length());
    stg=stg.trim();//strip from java 11 for knowledge
    System.out.println("The length of stg: "+stg.length());
	}

}
