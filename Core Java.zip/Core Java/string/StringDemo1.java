package org.anudip.string;

public class StringDemo1 {

	public static void main(String[] args) {
		String str="ABC";
		System.out.println("The value of str: "+str);
		String stg=str;
		System.out.println("The value of stg: "+stg);
		str=str+"DEF";
		System.out.println("The value of str: "+str);
		System.out.println("The value of stg: "+stg);
	}

}
