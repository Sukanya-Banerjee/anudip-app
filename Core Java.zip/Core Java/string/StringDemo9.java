package org.anudip.string;
import java.util.Scanner;
public class StringDemo9 {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a sentence: ");
	String str=scanner.nextLine();
	String [] arr=str.split("\\.");
	System.out.println("The number of words in sentence: "+arr.length);
	for(String s:arr)
	{
		System.out.println(s);
	}

	}

}
