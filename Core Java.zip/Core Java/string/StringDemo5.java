package org.anudip.string;

public class StringDemo5 {

	public static void main(String[] args) {
		String str="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		//String sub1=str.substring(5);
		//System.out.println(sub1);
		String sub2=str.substring(5,6);
		System.out.println(sub2);
	}

}
