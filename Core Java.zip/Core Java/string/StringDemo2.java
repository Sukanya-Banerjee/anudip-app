package org.anudip.string;

public class StringDemo2 {

	public static void main(String[] args) {
		String str="ABCDEFGH";
		//convert into char array
		char [] arr=str.toCharArray();
		System.out.println("The length of arr: "+arr.length);

	}

}
