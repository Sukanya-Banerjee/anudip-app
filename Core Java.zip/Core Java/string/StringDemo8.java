package org.anudip.string;
import java.util.Scanner;
public class StringDemo8 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a name of a person: ");
		String pname=scanner.nextLine();
		String [] arr=pname.split(" ");
		if(arr.length==3)
		{
			System.out.println("First name: "+arr[0]);
			System.out.println("Middle name: "+arr[1]);
			System.out.println("Surname: "+arr[2]);
		}
		else
		{
			System.out.println("First name: "+arr[0]);
			System.out.println("Surname: "+arr[1]);
		}

	}

}
