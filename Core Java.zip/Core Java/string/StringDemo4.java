package org.anudip.string;
import java.util.Scanner;
public class StringDemo4 {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a name of a person: ");
	String pname=scanner.nextLine();
	if(pname.endsWith("a")||pname.endsWith("i"))
       System.out.println("Name of a girl");
       else
    	System.out.println("Nmae of a boy");

	}

}
