package org.anudip.string;
import java.util.Scanner;
public class SubStringAppq2 {

	public static String cutString(String str, int n, int m)
	{
		n--;
		m=n+m;
		String sub=str.substring(n,m);
		return sub;

	}
	
	public static void main(String[] args)
	{
        Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=sc.nextLine();
		System.out.println("Enter the start position: ");
		int n=Integer.parseInt(sc.nextLine());
		n--;
		System.out.println("Enter the number of chars to display: ");
		int m=Integer.parseInt(sc.nextLine());
		
		String sub=cutString(str,n,m);
		System.out.println(sub);
	}
}
