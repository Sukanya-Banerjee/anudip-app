package org.anudip.exception;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import org.anudip.exception.AgeException;
import org.anudip.exception.VotarException;
public class VotarEnrollmentApplication {
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			System.out.println("Enter your date of birth: ");
			String birthDate = scanner.nextLine();
			scanner.close();
			LocalDate mybirthDate = LocalDate.parse(birthDate,dateFormat);
			LocalDate today = LocalDate.now();
			Period age = Period.between(mybirthDate, today);

			try {
	            if (age.getYears() < 1 || age.getYears() > 150) {
	                throw new AgeException("Wrong age. Age must be between 1 and 150.");
	            } else if (age.getYears() < 18) {
	                throw new VotarException("Invalid age for enrollment as a voter.");
	            } else {
	                System.out.println("Eligible for voter enrollment.");
	            }
	        } 
	        catch (AgeException ex) {
	            System.out.println("AgeException: " + ex.getMessage());
	        } //end of catch
	        catch (VotarException ex) {
	            System.out.println("VoterException: " + ex.getMessage());
	        }//end of catch
		}//end of main
	}//end of class