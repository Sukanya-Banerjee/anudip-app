package org.anudip.exception;
	public class VotarException extends Exception {
		static final long serialVersionUID=2L;
		 public VotarException(String message) {
		        super(message);
		    }
	}
