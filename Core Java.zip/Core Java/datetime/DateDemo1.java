package org.anudip.datetime;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
public class DateDemo1 {

	public static void main(String[] args) throws ParseException{
		Scanner scanner=new Scanner(System.in);
		//pattern for date input
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Enter Batch start date(dd-mm-yyyy): ");
        String startDate=scanner.nextLine();
       // System.out.println(startDate);
       //validate this date
        Date batchDate=dateFormat.parse(startDate);
        System.out.println(batchDate);
	}

}
