package org.anudip.interfaceApp;

public interface MyDemoFace {
public void show();
public default void display() {
	System.out.println("Hello how are you?");
}
public static void putdata() {
	System.out.println("Hi hello people");
}
}
