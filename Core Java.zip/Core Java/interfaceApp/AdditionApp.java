package org.anudip.interfaceApp;
import java.util.Scanner;
public class AdditionApp {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		AdditionFace af=(x,y)->{
			return x+y;
		};//end of Lambda
		System.out.println("Enter 1St Operand: ");
		int i=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter 2nd Operand: ");
		int j=Integer.parseInt(scanner.nextLine());
		int r=af.add(i, j);
		System.out.println("The result : "+r);

	}

}
