package org.anudip.interfaceApp;

public class DemoShape {

	public static void main(String[] args) {
		Shape df=new Circle();
		df.perimeter();
		df.area();
	}

}
