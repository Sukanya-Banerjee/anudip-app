package org.anudip.interfaceApp;

public class MyDemoApp {

	public static void main(String[] args) {
		MyDemoFaceImpl md=new MyDemoFaceImpl();
		md.show();
		md.display();
        MyDemoFace.putdata();
        md.dispMessage();
	}

}
