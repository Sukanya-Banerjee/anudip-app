package org.anudip.interfaceApp;

public class Parent implements AppFace {

	
	@Override
	public void show() {
		System.out.println("hi");
	}
	@Override
	public void display() {
		System.out.println("hello");
	}
	
	
}
