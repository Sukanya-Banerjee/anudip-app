package org.anudip.interfaceApp;

public class MyFaceApp {

	public static void main(String[] args) {
		MyFace mf=(stg)->{
        String str="Hello"+ stg+ "Welcome to Lambda expression";
        return str;
	};//end of Lambda expression
	String stk="Mary";
   System.out.println(mf.showMessage(stk));
}//end of main
}//end of class
