package org.anudip.interfaceApp;

public class DemoApp {

	public static void main(String[] args) {
	/*DemoFace df=new DemoFaceImpl();
	df.show();
	df.display();*/
	//df.putdata();
		AppFace af=new Child();
		af.show();
		af.display();
	}
}