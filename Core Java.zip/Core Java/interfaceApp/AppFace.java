package org.anudip.interfaceApp;

public interface AppFace {
      void show();
      void display();


}
