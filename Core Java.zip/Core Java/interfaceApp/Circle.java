package org.anudip.interfaceApp;

import java.text.DecimalFormat;
import java.util.Scanner;
public class Circle implements Shape {
   
        private static final DecimalFormat myFormat=new DecimalFormat("0.00");
        int r=5;
	@Override
	public String perimeter() {
		Double perimeter=2*r*pi;
		String peri=myFormat.format(perimeter);
		System.out.println("The perimeter is: "+perimeter);
		return peri;
	}

	@Override
	public String area() {
		Double area=pi*r*r;
		String area2=myFormat.format(area);
		System.out.println("The Area is: "+area);
		
		return area2;
		
	}

}
