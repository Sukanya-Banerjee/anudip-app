package org.anudip.oneToManyBiDirectional.application;
import java.util.List;
import org.anudip.oneToManyBiDirectional.bean.Commodity;
import org.anudip.oneToManyBiDirectional.bean.Suppliers;
import org.anudip.oneToManyBiDirectional.dao.DatabaseHandler;
import org.hibernate.Query;
import org.hibernate.Session;

public class SupplierCommodityshow {
	public static void main(String[]args)throws Exception{
	DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
	 Session session=dbHandler.createSession();
  	 String queryStatement="from Suppliers";
  	Query<Suppliers> query=session.createQuery(queryStatement);
   List<Suppliers> supplierList=query.list();
   supplierList.forEach(supplier->System.out.println(supplier));
	    session.close();
}
}