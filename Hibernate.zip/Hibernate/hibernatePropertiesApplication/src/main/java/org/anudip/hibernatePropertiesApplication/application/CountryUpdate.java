  package org.anudip.hibernatePropertiesApplication.application;

import java.util.List;
import java.util.Scanner;
import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.anudip.hibernatePropertiesApplication.dao.DatabaseHandler;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CountryUpdate {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the country code: ");
        int code = Integer.parseInt(scanner.nextLine());

        // Create a DatabaseHandler instance
        DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();

        // Create a Hibernate session
        Session session = dbHandler.createSession();
        Transaction transaction = null;

        try {
            // Create an HQL query to fetch countries by code
            String queryStatement = "FROM Country WHERE countryCode = :code";
            Query<Country> query = session.createQuery(queryStatement);
            query.setParameter("code", code);

            // Execute the query and get the list of matching countries
            List<Country> countryList = query.list();

            // Print the list of matching countries
            for (Country country : countryList) {
                System.out.println(country);
            }

            if (!countryList.isEmpty()) {
                System.out.println("Enter the new GDP value: ");
                double newGdp = Double.parseDouble(scanner.nextLine());

                // Start a transaction
                transaction = session.beginTransaction();

                // Update the GDP value for the matching countries
                for (Country country : countryList) {
                    country.setGdp(newGdp);
                    session.update(country);
                }

                // Commit the transaction
                transaction.commit();

                System.out.println("GDP values updated successfully.");
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback the transaction if an exception occurs
            }
            e.printStackTrace(); // Properly handle exceptions
        } finally {
            session.close();
            scanner.close(); // Close the Scanner
        }
    }
}
